package com.war;

public class Test {
    int a = 1;
    int[] test= new int[a];

    public void ok(int b){
        test[b] = 2;
    }

}

//  printDeck()
//        for(int i = 0; i < 4; ++i){
//            for(int j = 0; j < (size/4); j++){
//                deck[i][j].printCard();
//            }
//        }