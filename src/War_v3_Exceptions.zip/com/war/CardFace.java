package com.war;

interface CardFace {
    public void GetFaceObject(String face);
    public void GetValueObject(int value);
}
