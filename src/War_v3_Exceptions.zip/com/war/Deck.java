package com.war;

public class Deck {
    private int size = 52;
    PlayingCard deck[] =  new PlayingCard[(size*2)+1];

    private int numberOfHearts = size/4;
    private int numberOfSpades = size/4;
    private int numberOfDiamonds = size/4;
    private int numberOfClubs = size/4;

    public int getSize(){
        return  size;
    }

    public void setSize(int newSize){
       this.size = newSize;
    }

    public void createDeck(){
        try{
            //DEBUG IncorrectValuePassedException
//            deck[0] = new PlayingCard();
//            deck[0].setValue(15);
            for(int i = 0; i < this.size; i++){
                deck[i] = new PlayingCard();
                deck[i].setFace((i/13)+1);
                deck[i].setValue((i%13)+1);
            }
        } catch (IncorrectValuePassedException ivpe){
            System.out.println("Unable to create Deck. Adjust division");
            System.exit(-1);
        }
    }

    //DEBUG
    public void setCard(int position, PlayingCard card){
        this.deck[position] = card;
    }

    public PlayingCard getCard(int position){
        return this.deck[position];
    }


    public void shuffleDeck(){
        int random = (int) (Math.random( )*60);
        for(int i = 0; i < random; i++){
            int cardOne = (int) (Math.random( )*this.size);
            int cardTwo = (int) (Math.random( )*this.size);

            PlayingCard temp = this.deck[cardOne];

            this.deck[cardOne] = this.deck[cardTwo];
            this.deck[cardTwo] = temp;

        }
    }

    public void printDeck(){
        for(int i =0; i < this.size; i++){
            System.out.print((i+1) + ":");
            this.deck[i].printCard();
            System.out.println();
        }
    }
    //TODO; add equal
    public static boolean compareCard(PlayingCard a, PlayingCard b) throws SameCardException{
        if(a.getValue() > b.getValue()){
            return true;
        } else  if (a.getValue() == b.getValue()){
            throw  new SameCardException("Two equal values");
        } else {
            return false;
        }
    }
    //FIXME error when only two cards in deck
    public void insertCard(PlayingCard newCard, int insertPosition){
        this.size += 1;
        for(int i = this.size; i > insertPosition ; i--){
            this.deck[i] = this.deck[i-1];
        }
        this.deck[insertPosition] = newCard;
    }

    public void removeCard(int removePosition){
        this.size -= 1;
        for(int i = removePosition; i < this.size ; i++){
            this.deck[i] = this.deck[i+1];
        }
    }


}
