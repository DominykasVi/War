package com.war;

public class Main {

    public static void main(String[] args) {
        Deck a = new Deck();
        a.createDeck();
        Deck b = new Deck();
        b.createDeck();
        for(int i =0; i < 5 ;i++){
            a.shuffleDeck();
            b.shuffleDeck();
        }
        //DEBUG, kad ismestu exceptions
//        a.setCard(0, b.getCard(0)); // SameCardException
       //Incorrectvalue exception in deck file, line 22
        UserInterface gui = new UserInterface(a, b);
    }
}
